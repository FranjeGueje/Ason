#!/bin/sh

echo parent.sh running

./child.sh

