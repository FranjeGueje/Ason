#!/bin/sh

parent="$(ps -o comm= -p $PPID)"

echo $parent

if [ "$parent" != parent.sh ]; then
    echo this script should be directly executed by parent.sh, not by $parent
    exit 1
fi

echo "child.sh proceeding"

