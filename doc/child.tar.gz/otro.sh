#!/bin/bash

echo "top: $$"
sleep 5
echo "bottom: $$"
