#!/bin/bash

sleep 1000 &
sleep 1000 &
sleep 1000 &

sleep 100
