#!/bin/sh

echo other.sh running

./child.sh

