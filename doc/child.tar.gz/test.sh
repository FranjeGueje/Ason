#!/bin/bash

tree / > borrar.txt & pid=$!
{ sleep 1110; kill "$pid"; } &

exit 0

